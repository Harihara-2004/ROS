// generated from rosidl_generator_cpp/resource/idl.hpp.em
// generated code does not contain a copyright notice

#ifndef MY_ROBOT_INTERFACES__MSG__HARDWARE_STATUS_HPP_
#define MY_ROBOT_INTERFACES__MSG__HARDWARE_STATUS_HPP_

#include "my_robot_interfaces/msg/detail/hardware_status__struct.hpp"
#include "my_robot_interfaces/msg/detail/hardware_status__builder.hpp"
#include "my_robot_interfaces/msg/detail/hardware_status__traits.hpp"

#endif  // MY_ROBOT_INTERFACES__MSG__HARDWARE_STATUS_HPP_
