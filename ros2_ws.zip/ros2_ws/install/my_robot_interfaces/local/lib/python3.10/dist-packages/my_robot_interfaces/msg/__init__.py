from my_robot_interfaces.msg._hardware_status import HardwareStatus  # noqa: F401
