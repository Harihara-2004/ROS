#!/usr/bin/env python3
import rclpy
from rclpy.node import Node
from example_interfaces.msg import String
     
     
class RoverModel(Node): 
    def __init__(self):
        
        super().__init__("Rover") 
        self.rover_name = "H2"
        self.publishe = self.create_publisher(String,"rover_contact",10)
        self.timer_=self.create_timer(1,self.check)
        self.get_logger().info("Rover has Started")


    def check(self):
        details=String()
        details.data= "Hello this is "+str(self.rover_name)+" rover contacting from MARS"
        self.publishe.publish(details)

     
     
def main(args=None):
    rclpy.init(args=args)
    node = RoverModel() 
    rclpy.spin(node)
    rclpy.shutdown()
     
     
if __name__ == "__main__":
    main()